name = "frasa"

__version__ = "0.0.1"
__version_info__ = (0, 0, 1)