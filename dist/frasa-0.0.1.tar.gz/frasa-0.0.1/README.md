# Frasa

Coming Soon

### Instalasi
```
pip install frasa
```